<!DOCTYPE html>
<html>
<head>
  <title>Movie Ticket Booking Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #333333;
      padding: 10px;
    }

    nav {
      display: flex;
      justify-content: center;
    }

    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }

    nav ul li {
      display: inline-block;
      margin: 0 10px;
    }

    nav ul li a {
      color: #ffffff;
      text-decoration: none;
      font-weight: bold;
      padding: 5px;
    }

    nav ul li a:hover {
      background-color: #ffffff;
      color: #333333;
      border-radius: 5px;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    h1 {
      text-align: center;
    }
  </style>
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="bookings.php">Bookings</a></li>
        <li><a href="seats.php">Seats</a></li>
        <li><a href="add_admin.php">Add New Admin</a></li>
        <li><a href="customers.php">Customers</a></li>
      </ul>
    </nav>
  </header>

  <div class="container">
    <h1>Welcome to the Movie Ticket Booking Dashboard</h1>
    <!-- Rest of the content -->
  </div>
</body>
</html>
