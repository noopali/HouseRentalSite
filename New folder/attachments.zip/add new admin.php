<!DOCTYPE html>
<html>
<head>
  <title>Add New Admin - Movie Ticket Booking</title>
</head>
<body>
  <h1>Add New Admin</h1>
  <!-- Add New Admin content -->
</body>
</html>
