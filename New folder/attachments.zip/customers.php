<!DOCTYPE html>
<html>
<head>
  <title>Customers - Movie Ticket Booking</title>
</head>
<body>
  <h1>Customers</h1>
  <!-- Customers content -->
</body>
</html>
