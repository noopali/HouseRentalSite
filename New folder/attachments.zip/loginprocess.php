<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get form data
  $username = $_POST["username"];
  $password = $_POST["password"];

  // Validate form data (you can add more validation as per your requirements)
  if (empty($username) || empty($password)) {
    echo "Please fill in all fields.";
  } else {
    // Database connection (replace with your own credentials)
    $servername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "movie_db";

    $conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);

    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Check if the username exists in the database
    $sql = "SELECT Cust_password FROM customer WHERE Cust_name =$username";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
      $row = $result->fetch_assoc();
      $storedPassword = $row["Cust_password"];

      // Verify the password
      if (password_verify($password, $storedPassword)) {
        // Password is correct, user is logged in
        echo "Login successful.";
        $_SESSION["username"]=$_post["Cust_name"];
        header("location:home.html");
      } else {
        echo "Incorrect password.";
      }
    } else {
      echo "Username not found.";
    }

    $stmt->close();
    $conn->close();
  }
}
?>
