<!DOCTYPE html>
<html>
<head>
  <title>Dashboard - Movie Ticket Booking</title>
</head>
<body>
  <h1>Dashboard</h1>
  <!-- Dashboard content -->
</body>
</html>
