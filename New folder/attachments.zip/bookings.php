<!DOCTYPE html>
<html>
<head>
  <title>Bookings - Movie Ticket Booking</title>
</head>
<body>
  <h1>Bookings</h1>
  <!-- Bookings content -->
</body>
</html>
