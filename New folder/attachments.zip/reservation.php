<!DOCTYPE html>
<html>
<head>
  <title>Seats - Movie Ticket Booking</title>
</head>
<body>
  <h1>Reservation</h1>
  <!-- Seats content -->
</body>
</html>
