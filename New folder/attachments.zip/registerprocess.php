<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get form data
  print_r($_POST);
  $name = $_POST["Name"];
  $password = $_POST["Password"];
  $confirmPassword = $_POST["Confirm_Password"];
  $address = $_POST["Address"];
  $contact = $_POST["Contact"];
  $dob = $_POST["DOB"];
  $gender = $_POST["Gender"];

  // Validate form data (you can add more validation as per your requirements)
  if (empty($name) || empty($password) || empty($confirmPassword) || empty($address) || empty($contact) || empty($dob) || empty($gender)) {
    echo "Please fill in all fields.";
  } elseif ($password != $confirmPassword) {
    echo "Passwords do not match.";
  } else {
    // Database connection (replace with your own credentials)
    $servername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "movie_db";

    $conn = new mysqli($servername, $dbUsername, $dbPassword, $dbName);

    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Check if username already exists
    $sql = "SELECT Cust_id FROM customer WHERE Cust_name ='$name'";
    $stmt = $conn->prepare($sql);
    
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
      echo "Username already exists. Please choose a different username.";
    } else {
      // Insert new user into the database
      $sql = "INSERT INTO customer (Cust_id, Cust_name, Cust_address, Cust_contact, Cust_DOB, Cust_password, Cust_gender) VALUES ($id, $name, $address, $contact, $dob, $password, $gender)";
      $stmt = $conn->prepare($sql);
      $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
      $stmt->bind_param("ssssss", $name, $address, $contact, $dob, $hashedPassword, $gender);

      if ($stmt->execute()) {
        echo "Registration successful.";
      } else {
        echo "Error: " . $stmt->error;
      }
    }

    $stmt->close();
    $conn->close();
  }
}
?>
